import devnet


def main():
    devnet.main()


if __name__ == '__main__':
    main()
