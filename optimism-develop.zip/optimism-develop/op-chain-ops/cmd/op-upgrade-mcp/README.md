# op-upgrade-mcp

One off CLI tooling for the mcp upgrade
