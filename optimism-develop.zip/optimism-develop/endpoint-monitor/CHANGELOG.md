# @eth-optimism/endpoint-monitor

## 1.0.3

### Patch Changes

- [#7450](https://github.com/ethereum-optimism/optimism/pull/7450) [`ac90e16a7`](https://github.com/ethereum-optimism/optimism/commit/ac90e16a7f85c4f73661ae6023135c3d00421c1e) Thanks [@roninjin10](https://github.com/roninjin10)! - Updated dev dependencies related to testing that is causing audit tooling to report failures

## 1.0.2

### Patch Changes

- [#6164](https://github.com/ethereum-optimism/optimism/pull/6164) [`c11039060`](https://github.com/ethereum-optimism/optimism/commit/c11039060bc037a88916c2cba602687b6d69ad1a) Thanks [@pengin7384](https://github.com/pengin7384)! - fix typo

## 1.0.1

### Patch Changes

- f505078be: Update go-ethereum to v1.10.26

## 1.0.0

### Major Changes

- a10c2b49: Initial release of endpoint monitor
