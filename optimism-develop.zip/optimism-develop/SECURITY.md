Please see our security policy document [here](https://github.com/ethereum-optimism/.github/blob/master/SECURITY.md).
