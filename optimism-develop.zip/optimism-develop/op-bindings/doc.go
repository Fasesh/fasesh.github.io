/*

The contracts package provides Go bindings for our contracts.


To regenerate the bindings, run `make`
The following programs are required: `jq`, `abigen`, and `solc` (at version 0.8.10)
*/

package op_bindings
