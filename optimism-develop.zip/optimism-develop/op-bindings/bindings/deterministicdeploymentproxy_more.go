// Code generated - DO NOT EDIT.
// This file is a generated binding and any manual changes will be lost.

package bindings

var DeterministicDeploymentProxyDeployedBin = "0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe03601600081602082378035828234f58015156039578182fd5b8082525050506014600cf3"
func init() {
	deployedBytecodes["DeterministicDeploymentProxy"] = DeterministicDeploymentProxyDeployedBin
}
