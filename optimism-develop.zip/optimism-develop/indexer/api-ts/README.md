Generated typescript types for https://github.com/ethereum-optimism/optimism/tree/develop/indexer
